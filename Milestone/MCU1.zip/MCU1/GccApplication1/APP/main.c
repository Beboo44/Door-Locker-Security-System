/*
 * GccApplication1.c
 *
 * Created: 9/9/2024 1:36:54 PM
 * Author : pc
 */ 


#include "program.h"

#define F_CPU 8000000UL
#include "util/delay.h"



extern u32 Timer0_NumOfCM;
extern u32 Timer0_NumOfOV;

extern u8 correct;

int main(void)
{
	cnt =0 ;
	counter=0;
	correct=0;
	u32 top_value = 19999;
	KEYPAD_voidInit();
	LCD_voidInit();
	UART_init(9600);
	ADC_init(ADC_Divide_by_4);
	Timer0_voidInit();
	Timer0_voidEnableInt(TIMER0_COMP_MATCH_INT_ID);
	Timer0_voidSetTime(1000);
	Timer0_voidStart();
	TIMER1_vInit();
	TIMER1_vStart();
	
	
	Set_password();
	UART_sendByte('p');
	UART_sendString(pass);
	Keypad_Flag=0;
	u8 temp0=0;
	u8 currTemp;
	Main_Menu();
    while (1){
		
		Keypad_Input();
		u8 data = KEYPAD_u8ReadButton(Keypad_Row,Keypad_Col);
		if(Keypad_Flag){
			if(data=='+'){
				correct = 0;
				Keypad_Flag=0;
				LCD_ClearScreen();
				LCD_SendString("ENTER PASS:");
				LCD_MoveCursor(LCD_Row1,LCD_Col0);
				Enter_password(3);
				
				if(correct==0){
					UART_sendByte('b');
					error_handling();
					UART_sendByte('b');
					forget_pass();
					continue;
				}
				
				UART_sendByte('d');
				door();
				Main_Menu();
			}
			else if (data=='-'){
				LCD_ClearScreen();
				Set_password();
				UART_sendByte('p');
				UART_sendString(pass);
				Main_Menu();
			}
			Keypad_Flag=0;
		}
		u16 digital_signal = ADC_readChannel_single_conv(ADC_CHANNEL_0);
		currTemp = LM35_getTemperature(digital_signal);
	
		if(currTemp!=temp0){
			temp0 = currTemp;
			if(currTemp>35){
			TIMER1_SetFastPWMICR(top_value,100);
			}
			else if (currTemp>25 && currTemp<=35)
			TIMER1_SetFastPWMICR(top_value,50);
			else if (currTemp>20 &&  currTemp<=25)
			TIMER1_SetFastPWMICR(top_value,10);
			else
			TIMER1_SetFastPWMICR(top_value,0);
		}
			
			
	}
}


ISR(TIMER0_COMP_VECT){
	++cnt;
	if(cnt == Timer0_NumOfCM){
		++counter;
		cnt = 0;
	}
}
