/*
 * EXIT.c
 *
 * Created: 2024/09/07 1:32:04 PM
 *  Author: Home
 */ 

#include "EXT_INTERRUPT.h"


void EXTI_voidInit(u8 Copy_u8INT_Number, u8 Copy_u8Sense_Control)
{
	switch(Copy_u8INT_Number)
	{
		case EXT_INT0_ID:
		SetBit(GICR,GICR_INT_0);
		switch(Copy_u8Sense_Control)
		{
			case LOW_LEVEL:
			ClrBit(MCUCR,MCUCR_ISC00);
			ClrBit(MCUCR,MCUCR_ISC01);
			break;
			case LOGICAL_CHANGE:
			SetBit(MCUCR,MCUCR_ISC00);
			ClrBit(MCUCR,MCUCR_ISC01);
			break;
			case FALLING_EDGE:
			ClrBit(MCUCR,MCUCR_ISC00);
			SetBit(MCUCR,MCUCR_ISC01);
			break;
			case RISING_EDGE:
			SetBit(MCUCR,MCUCR_ISC00);
			SetBit(MCUCR,MCUCR_ISC01);
			break;
		}
		break;
		case EXT_INT1_ID:
		SetBit(GICR,GICR_INT_1);
		switch(Copy_u8Sense_Control)
		{
			case LOW_LEVEL:
			ClrBit(MCUCR,MCUCR_ISC10);
			ClrBit(MCUCR,MCUCR_ISC11);
			break;
			case LOGICAL_CHANGE:
			SetBit(MCUCR,MCUCR_ISC10);
			ClrBit(MCUCR,MCUCR_ISC11);
			break;
			case FALLING_EDGE:
			ClrBit(MCUCR,MCUCR_ISC10);
			SetBit(MCUCR,MCUCR_ISC11);
			break;
			case RISING_EDGE:
			SetBit(MCUCR,MCUCR_ISC10);
			SetBit(MCUCR,MCUCR_ISC11);
			break;
		}
		break;
		case EXT_INT2_ID:
		SetBit(GICR,GICR_INT_2);
		switch(Copy_u8Sense_Control)
		{
			case FALLING_EDGE:
			ClrBit(MCUCSR,MCUCSR_ISC2);
			break;
			case RISING_EDGE:
			SetBit(MCUCSR,MCUCSR_ISC2);
			break;
		}
		break;
	}
}
