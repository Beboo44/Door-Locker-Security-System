/*
 * CFile1.c
 *
 * Created: 2024/09/09 7:17:32 PM
 *  Author: Home
 */ 
#include "../LIB/std_types.h"
#include "../LIB/BitMath.h"
#include "TIMER0_Private.h"
#include "TIMER0_Config.h"
#include "TIMER0_interface.h"
#include "EXT_INTERRUPT.h"
#include "DIO.h"
#include <stdlib.h>

u32  Timer0_NumOfOV = 0;
u32  Timer0_NumOfCM = 0;

void Timer0_vInit(void)
{
	// step 1 : config Timer Mode
	#if (TIMER0_MODE == TIMER0_NORMAL_MODE)
	
	ClrBit(TCCR0, WGM01);
	ClrBit(TCCR0,WGM00);
	
	#elif (TIMER0_MODE == TIMER0_PHASECORRECT_MODE)
	
	ClrBit(TCCR0, WGM01);
	SetBit(TCCR0,WGM00);
	
	#elif (TIMER0_MODE == TIMER0_CTC_MODE)
	
	SetBit(TCCR0, WGM01);
	ClrBit(TCCR0,WGM00);
	
	#elif (TIMER0_MODE == TIMER0_FASTPWM_MODE)
	
	SetBit(TCCR0, WGM01);
	SetBit(TCCR0,WGM00);
	
	#endif
}


void Timer0_vEnableInt(u8 IntId)
//we have 2 interrupts. overflow w compare
{
	// step 2 : Enable interrupt Mode
	sei();
	switch (IntId){
		case TIMER0_OVF_INT_ID:
		SetBit(TIMSK,TOIE0);
		break;
		
		case TIMER0_COMP_MATCH_INT_ID:
		SetBit(TIMSK,OCIE0);
		break;
		
		default:break;
	}
	

}


void Timer0_vDisableInt(u8 IntId)
{
	// step 1 : config Timer Mode
	switch (IntId)
	{
		case TIMER0_OVF_INT_ID:
		ClrBit(TIMSK,TOIE0);
		break;
		
		case TIMER0_COMP_MATCH_INT_ID:
		ClrBit(TIMSK,OCIE0);
		break;
		
		default:break;
	}
}

void Timer0_vStart(void)
{
	//step 1 : clear TCNT0
	
	ClrBit(TCCR0,CS00);
	
	//step 2 : insert clock
	#if( TIMER0_PRESCALER ==  TIMER0_PRESCALER_1 )
	SetBit(TCCR0,CS00);
	ClrBit(TCCR0,CS01);
	ClrBit(TCCR0,CS02);
	
	
	#elif( TIMER0_PRESCALER ==  TIMER0_PRESCALER_8 )
	SetBit(TCCR0,CS01);
	ClrBit(TCCR0,CS00);
	ClrBit(TCCR0,CS02);

	#elif( TIMER0_PRESCALER ==  TIMER0_PRESCALER_64 )
	SetBit(TCCR0,CS00);
	SetBit(TCCR0,CS01);
	ClrBit(TCCR0,CS02);
	

	#elif( TIMER0_PRESCALER ==  TIMER0_PRESCALER_256 )
	ClrBit(TCCR0,CS00);
	ClrBit(TCCR0,CS01);
	SetBit(TCCR0,CS02);

	#elif( TIMER0_PRESCALER ==  TIMER0_PRESCALER_1024)
	SetBit(TCCR0,CS00);
	ClrBit(TCCR0,CS01);
	SetBit(TCCR0,CS02);
	
	#elif( TIMER0_PRESCALER ==  TIMER0_PRESCALER_EXTCLK_FALLEDGE)

	
	#elif( TIMER0_PRESCALER ==  TIMER0_PRESCALER_EXTCLK_RAISEDGE)


	#endif
}

void Timer0_vStop(void)
{
	// Clear all clock selection bits to stop the timer
	ClrBit(TCCR0,CS00);
	ClrBit(TCCR0,CS01);
	ClrBit(TCCR0,CS02);
}


void Timer0_vSetTime(u32 DesiredTime_ms)
{
	u32 prescaler[5]={1, 8, 64, 256, 1024};
	u32 ticktime   = (prescaler[TIMER0_PRESCALER ]*1000)/F_OSC;		//TickTime in us
	u32 TotalTicks = (DesiredTime_ms * 1000000) / ticktime;			//no of ticks needed for overflow
	// If the timer is in Normal mode
	#if( TIMER0_MODE ==  TIMER0_NORMAL_MODE )
	Timer0_NumOfOV = TotalTicks /256;
	#elif( TIMER0_MODE ==  TIMER0_CTC_MODE)
	u16 limit = 0 ;
	for(u16 i = 256; i>0; i--)
	{
		if(TotalTicks%i==0)
		{
			limit = i; 
			break;
		}
	}
	if(limit==0)
		limit = 256;
	OCR0=limit;
	Timer0_NumOfCM = TotalTicks/limit;
	#endif
}

// Function to set the duty cycle for Fast PWM mode
void Timer0_SetFastPWM(f32 DutyCycle)
{
	SetPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT); //OC0
	
	#if (TIMER0_MODE == TIMER0_FASTPWM_MODE)
	
	#if ( TIMER0_OC0_MODE  == TIMER_OC0_PWM_NON_INVERTING)
	SetBit(TCCR0,COM01);
	ClrBit(TCCR0, COM00);
	OCR0= abs(((256*DutyCycle)/100)-1);
	
	#elif (TIMER0_OC0_MODE  == TIMER_OC0_PWM_INVERTING)
	SetBit(TCCR0 ,COM01);
	SetBit(TCCR0, COM00);
	OCR0= 255-abs(((256*DutyCycle)/100)-1);
	#endif
	
	#endif
}



// Function to set the duty cycle for Phase Correct PWM mode
void Timer0_SetPhaseCorrect(f32 DutyCycle)
{
	// Set pin PB3 (OC0) as output
	SetPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT); //OC3

	#if (TIMER0_MODE == TIMER0_PHASECORRECT_MODE)
	
	#if ( TIMER0_OC0_MODE  == TIMER_OC0_PWM_NON_INVERTING)

	SetBit(TCCR0,COM01);
	ClrBit(TCCR0, COM00);
	OCR0= abs(((256*DutyCycle)/100)-1);
	
	#elif ( TIMER0_OC0_MODE  == TIMER_OC0_PWM_INVERTING)
	
	SetBit(TCCR0 ,COM01);
	SetBit(TCCR0, COM00);
	OCR0= 255-abs(((256*DutyCycle)/100)-1);
	
	#endif
	#endif
}

f32 Duty_Cycle_Calculation (f32 Speed)
{
	f32 Duty = (((Speed/100.0)*5)/5.0) * (((Speed/100.0)*5)/5.0) ; 
	return Duty*100;
}