/*
 * DIO.c
 *
 * Created: 2024/08/25 4:31:23 PM
 *  Author: Karim Maaty
 */ 

#include"DIO.h"

void SetPinDirection (u8 Copy_u8PORT , u8 Copy_u8PIN , u8 Copy_u8DIRECTION)
{
	if(Copy_u8DIRECTION==PIN_OUTPUT)
	{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				SetBit(DDRA,Copy_u8PIN);
				break;		
			case PORTB_ID:	
				SetBit(DDRB,Copy_u8PIN);
				break;		
			case PORTC_ID:	
				SetBit(DDRC,Copy_u8PIN);
				break;		
			case PORTD_ID:	
				SetBit(DDRD,Copy_u8PIN);
				break;
		}
	}
	else if(Copy_u8DIRECTION==PIN_INPUT)
	{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				ClrBit(DDRA,Copy_u8PIN);
				break;
			case PORTB_ID:
				ClrBit(DDRB,Copy_u8PIN);
				break;
			case PORTC_ID:
				ClrBit(DDRC,Copy_u8PIN);
				break;
			case PORTD_ID:
				ClrBit(DDRD,Copy_u8PIN);
				break;
		}
	}
}

void SetPinValue (u8 Copy_u8PORT ,u8 Copy_u8PIN ,u8 Copy_u8VALUE)
{
	if(Copy_u8VALUE==PIN_HIGH)
	{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				SetBit(PORTA,Copy_u8PIN);
				break;
			case PORTB_ID:
				SetBit(PORTB,Copy_u8PIN);
				break;
			case PORTC_ID:
				SetBit(PORTC,Copy_u8PIN);
				break;
			case PORTD_ID:
				SetBit(PORTD,Copy_u8PIN);
				break;
		}
	}
	else if (Copy_u8VALUE==PIN_LOW)
	{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				ClrBit(PORTA,Copy_u8PIN);
				break;
			case PORTB_ID:
				ClrBit(PORTB,Copy_u8PIN);
				break;
			case PORTC_ID:
				ClrBit(PORTC,Copy_u8PIN);
				break;
			case PORTD_ID:
				ClrBit(PORTD,Copy_u8PIN);
				break;
		}
	}
}

u8 GetPinValue(u8 Copy_u8PORT, u8 Copy_u8PIN)
{
	switch(Copy_u8PORT)
	{
		case PORTA_ID:
		return GetBit(PINA,Copy_u8PIN);
		case PORTB_ID:
		return GetBit(PINB,Copy_u8PIN);
		case PORTC_ID:
		return GetBit(PINC,Copy_u8PIN);
		case PORTD_ID:
		return GetBit(PIND,Copy_u8PIN);
	}
}

void TogglePin(u8 Copy_u8PORT,u8 Copy_u8PIN)
{
	switch(Copy_u8PORT)
	{
		case PORTA_ID:
			TogBit(PORTA,Copy_u8PIN);
			break;
		case PORTB_ID:
			TogBit(PORTB,Copy_u8PIN);
			break;
		case PORTC_ID:
			TogBit(PORTC,Copy_u8PIN);
			break;	
		case PORTD_ID:
			TogBit(PORTD,Copy_u8PIN);
			break;
	}
}

void SetPortDirection (u8 Copy_u8PORT , u8 Copy_u8DIRECTION)
{
	if(Copy_u8DIRECTION==PORT_OUTPUT)
	{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				DDRA = PORT_OUTPUT;
				break;
			case PORTB_ID:
				DDRB = PORT_OUTPUT;
				break;
			case PORTC_ID:
				DDRC = PORT_OUTPUT;
				break;
			case PORTD_ID:
				DDRD = PORT_OUTPUT;
				break;
		}
	}
	else if(Copy_u8DIRECTION==PORT_INPUT)
	{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				DDRA = PORT_INPUT;
				break;
			case PORTB_ID:
				DDRB = PORT_INPUT;
				break;
			case PORTC_ID:
				DDRC = PORT_INPUT;
				break;
			case PORTD_ID:
				DDRD = PORT_INPUT;
				break;
		}
	}
}
void SetPortValue(u8 Copy_u8PORT , u8 Copy_u8VALUE)
{
		switch(Copy_u8PORT)
		{
			case PORTA_ID:
				PORTA = Copy_u8VALUE;
				break;
			case PORTB_ID:
				PORTB = Copy_u8VALUE;
				break;
			case PORTC_ID:
				PORTC = Copy_u8VALUE;
				break;
			case PORTD_ID:
				PORTD = Copy_u8VALUE;
				break;
		}
}



