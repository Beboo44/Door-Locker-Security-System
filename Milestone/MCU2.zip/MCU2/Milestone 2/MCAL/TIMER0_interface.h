/*
 * TIMER0_interface.h
 *
 * Created: 9/2/2024 4:37:10 PM
 *  Author: Karim Mohamed
 */
 
#include "../LIB/std_types.h"

#ifndef TIMER0_INTERFACE_H_
#define TIMER0_INTERFACE_H_

#define TIMER0_OVF_INT_ID          0
#define TIMER0_COMP_MATCH_INT_ID   1

void Timer0_vInit(void);					// checks on the mode we are using 
void Timer0_vStop(void);				
void Timer0_vStart(void);					// Starts the clock by the prescaler 
void Timer0_vEnableInt(u8 IntId);			// enable the Interrupt (overflow or compare)
void Timer0_vDisableInt(u8 IntId);	
void Timer0_vSetTime(u32 DesiredTime_ms);	
void Timer0_SetPhaseCorrect(f32 DutyCycle);
void Timer0_SetFastPWM(f32 DutyCycle);
f32 Duty_Cycle_Calculation (f32 Speed);

#endif /* TIMER0_INTERFACE_H_ */