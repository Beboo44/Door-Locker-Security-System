/*
 * Exit.h
 *
 * Created: 2024/09/02 4:59:27 PM
 *  Author: Home
 */ 



#ifndef EXIT_H_
#define EXIT_H_

#include "../LIB/std_types.h"
#include "../LIB/BitMath.h"


#define sei() __asm__ __volatile__("sei");

#define INT0_vect		__vector_1
#define INT1_vect		__vector_2
#define INT2_vect		__vector_3
#define TIMER0_COMP		__vector_10
#define TIMER0_OVF		__vector_11


#define	ISR(VECT_NO)\
void VECT_NO(void) __attribute__((signal)); \
void VECT_NO(void)


#define NULL 0

#define LOW_LEVEL		0
#define LOGICAL_CHANGE	1 
#define RISING_EDGE		2
#define FALLING_EDGE	3

#define EXT_INT0_ID		6
#define EXT_INT1_ID		7
#define EXT_INT2_ID		5

#define	SREG			*((volatile u8*) 0x5F) //Status Register -> GIE enable 
#define	SREG_I			7

#define	GICR			*((volatile u8*) 0x5B) //General Interrupt Control Register -> PIE enable
#define	GICR_INT_0		6
#define	GICR_INT_1		7
#define	GICR_INT_2		5

#define	GIFR			*((volatile u8*) 0x5A) //General Interrupt flag Register -> PIF bas malo4 lazma 
#define	GIFR_INT_0		6
#define	GIFR_INT_1		7
#define	GIFR_INT_2		5

#define	MCUCR			*((volatile u8*) 0x55) //MCU Control Register -> Rising edge or falling edge 
#define	MCUCR_ISC00		0
#define	MCUCR_ISC01		1
#define	MCUCR_ISC10		2
#define	MCUCR_ISC11		3

#define	MCUCSR			*((volatile u8*) 0x54) //MCU Control and Status register -> Rising edge of falling edge for interrupt 2 
#define MCUCSR_ISC2		6

/*functions*/
void EXTI_voidGlobalINT_Enable();
void EXTI_voidGlobalINT_Disable();
void EXTI_voidInit(u8 Copy_u8INT_Number, u8 Copy_u8Sense_Control);
void EXTI_voidDisableInterrupt(u8 Copy_u8INT_Number);
u8 EXTI_u8GetFlag(u8 Copy_u8INT_Number);
void EXTI_voidSetCallBack(void (*Copy_pvoidCallBack)(void) , u8 Copy_u8INT_Number);





#endif /* EXIT_H_ */