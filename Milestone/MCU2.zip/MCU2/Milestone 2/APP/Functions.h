/*
 * Functions.h
 *
 * Created: 2024/09/26 1:48:08 AM
 *  Author: Karim Maaty
 */ 


#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

#define F_CPU 8000000UL
#include <util/delay.h>
#include "../HAL/Buzzer.h"
#include "../MCAL/TIMER0_interface.h"
#include "../MCAL/Timer1_Interface.h"

void vSet_Password(void);
void vCheck_Password(void);

#endif /* FUNCTIONS_H_ */