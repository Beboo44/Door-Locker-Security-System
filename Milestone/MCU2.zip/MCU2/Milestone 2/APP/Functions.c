/*
 * Functions.c
 *
 * Created: 2024/09/26 1:47:56 AM
 *  Author: Karim Maaty
 */ 

#include "Functions.h"

//to store the password
u8 Password[6];
//to compare the new input with the password
u8 TempPass[6];

void vSet_Password()
{
	//to receive the password sent by MCU1
	UART_receiveString(Password);
}

void vCheck_Password()
{
	//to receive the input sent by MCU1
	UART_receiveString(TempPass);
	for(u8 i = 0; i<6; i++)
	{
		if(Password[i]==TempPass[i])//to check on every character 
		{
			if(i==5)
				UART_sendByte('1');//to tell MCU1 that the entered pass is correct
			continue;
		}
		else
		{ 
			UART_sendByte('0');//to tell MCU1 that the entered pass wasn't correct 
			break;
		}
	}		
}

