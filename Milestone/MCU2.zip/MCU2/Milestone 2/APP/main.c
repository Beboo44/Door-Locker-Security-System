/*
 * Milestone 2.c
 * Description: Control unit of the security system
 * Created: 2024/09/25 9:48:55 PM
 * Author : Karim Maaty
 */ 

#define F_CPU 8000000UL
#include <util/delay.h>
#include "Functions.h"
#include "../HAL/Buzzer.h"
#include "../HAL/SERVO.h"
#include "../MCAL/UART_interface.h"
#include "../MCAL/TIMER0_interface.h"
#include "../MCAL/Timer1_Interface.h"
#include "../MCAL/Timer1_Config.h"
#include "../MCAL/TIMER1_Private.h"


u8 Order;
#define Buzzer 0 //enter the id of the pin

int main(void)
{
    TIMER1_vInit();
	TIMER1_vStart();
	BUZZER_SetPin(PORTC_ID,Buzzer);
	UART_init(9600);
    while (1) 
    {
		//Check which option is needed by MCU1
		Order=UART_recieveByte();
		
		//to Store the password enetered by the user
		if(Order == 'p')
			vSet_Password();
		
		//To compare the input with the First Passowrd
		else if(Order == 'c')
			vCheck_Password();
			
		//To open the door and close it again 
		else if(Order == 'd')
		{
			Servo_Open();		
			_delay_ms(1000);
			UART_sendByte('u');
			Servo_Close();	
			UART_sendByte('l');	
		}
		
		//TO turn on/off the buzzer
		else if(Order =='b')
		{
			BUZZER_Toggle(PORTC_ID,Buzzer);
		
		}
		
    }
}

