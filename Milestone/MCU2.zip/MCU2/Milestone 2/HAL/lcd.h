/*
 * lcd.h
 *
 * Created: 2024/08/28 12:44:14 PM
 *  Author: Karim Maaty 
 */ 

#define F_CPU 8000000UL
#include <util/delay.h>
#include "lcd_types.h"
#include "../MCAL/DIO.h"
#include "../LIB/BitMath.h"
#include "../LIB/std_types.h"

#ifndef LCD_H_
#define LCD_H_
#define LCD_DATA_MODE 8

void Command(u8 Command);
void LCD_Data(u8 data);
void LCD_Init(void);
void Data_Entery(void);
void LCD_SendString(const u8 *str);
void LCD_CursorShift(u8 Shift_Direction);
void LCD_Clear(void);
void LCD_DisplayCounter (u16 counter);
void LCD_SetCGRAMAddress();
void LCD_PrintCustomCharacter(u8 row, u8 column, u8 num);


#endif /* LCD_H_ */