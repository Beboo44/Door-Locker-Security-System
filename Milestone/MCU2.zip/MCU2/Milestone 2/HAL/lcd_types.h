/*
 * lcdtypes.h
 *
 * Created: 2024/08/28 12:44:02 PM
 *  Author: Home
 */ 

#include "../MCAL/DIO.h"

#ifndef LCD_TYPES_H_
#define LCD_TYPES_H_


#define LCD_CONTROL_PORT  PORTA_ID
#define LCD_DATA_PORT	  PORTC_ID

/*****************pins*****************/

#define LCD_RS_PIN	PIN2_ID
#define LCD_RW_PIN	PIN1_ID
#define LCD_E_PIN	PIN0_ID

#define LCD_D0_PIN	PIN0_ID
#define LCD_D1_PIN	PIN1_ID
#define LCD_D2_PIN	PIN2_ID
#define LCD_D3_PIN	PIN3_ID
#define LCD_D4_PIN	PIN4_ID
#define LCD_D5_PIN	PIN5_ID
#define LCD_D6_PIN	PIN6_ID
#define LCD_D7_PIN	PIN7_ID

/***************commands***************/

#define Clear_Display				0x01
#define Return_Home					0x02
#define Entry_Mode_Set				0x06
#define Display_on					0x0C
#define Display_off					0x08
#define Cursor_Right_Shift			0x14
#define Cursor_Left_Shift			0x10
#define Display_Right_Shift			0x1C
#define Display_Left_Shift			0x18
#define Set_Fun_8bit_2line_5x10dots	0x3F
#define LEFT	0
#define RIGHT	1
#endif   