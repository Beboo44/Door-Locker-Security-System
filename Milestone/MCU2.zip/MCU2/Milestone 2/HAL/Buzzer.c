/*
 * Buzzer.c
 *
 * Created: 2024/09/21 2:27:21 AM
 *  Author: Karim Maaty
 */ 

#include "BUZZER.h"

void BUZZER_SetPin(u8 PORT_ID, u8 PIN_ID)
{
	SetPinDirection(PORT_ID,PIN_ID,PIN_OUTPUT);
}

void BUZZER_TurnON(u8 PORT_ID, u8 PIN_ID)
{
	SetPinValue(PORT_ID,PIN_ID,PIN_HIGH);
}

void BUZZER_TurnOFF(u8 PORT_ID, u8 PIN_ID)
{
	SetPinValue(PORT_ID,PIN_ID,PIN_LOW);
}

void BUZZER_Toggle(u8 PORT_ID, u8 PIN_ID)
{
	TogglePin(PORT_ID,PIN_ID);
}