/*
 * lcd.c
 *
 * Created: 2024/08/28 12:44:23 PM
 *  Author: Home
 */ 

#include "lcd.h"

extern u8 a;
extern u8 b;
extern u8 c;
extern u8 d;


#if (LCD_DATA_MODE!=8)

#error "data must be 8"

#endif

void Data_Entery(void)
{
	SetPinValue(LCD_CONTROL_PORT,LCD_E_PIN,PIN_HIGH);
	_delay_ms(2);
	SetPinValue(LCD_CONTROL_PORT,LCD_E_PIN,PIN_LOW);
}

void Command(u8 Command)
{
	SetPinValue(LCD_CONTROL_PORT,LCD_RS_PIN,PIN_LOW);
	SetPinValue(LCD_CONTROL_PORT,LCD_RW_PIN,PIN_LOW);
	
	SetPortValue(LCD_DATA_PORT,Command);
	
	Data_Entery();
}

void LCD_Init(void)
{
	SetPortDirection(LCD_CONTROL_PORT,PORT_OUTPUT);
	SetPortDirection(LCD_DATA_PORT,PORT_OUTPUT);
	_delay_ms(35);
	Command(Set_Fun_8bit_2line_5x10dots);
	_delay_us(40);
	Command(Display_on);
	_delay_us(40);
	Command(Clear_Display);
	_delay_ms(2);
	Command(Entry_Mode_Set);
	_delay_ms(2);
	Data_Entery();
}

void LCD_Data(u8 data)
{
	SetPinValue(LCD_CONTROL_PORT,LCD_RS_PIN,PIN_HIGH);
	SetPinValue(LCD_CONTROL_PORT,LCD_RW_PIN,PIN_LOW);
	
	SetPortValue(LCD_DATA_PORT,data);
		
	Data_Entery();
}

void LCD_SendString(const u8 *str)
{
	for(u8 i = 0 ;str[i]!='\0';i++)
		LCD_Data(str[i]);
}

void LCD_CursorShift(u8 Shift_Direction)
{
	if(Shift_Direction==LEFT)
		Command(Cursor_Left_Shift);
	else if(Shift_Direction==RIGHT)
		Command(Cursor_Right_Shift);
}

void LCD_Clear()
{
	Command(Clear_Display);
}

void LCD_SetCursor(u8 row, u8 column)
{
	u8 address;
	if(row<2&&column<16)
	{
		address=(row*64)+column;
		address=SetBit(address,PIN7_ID);
		Command(address);
	}
}



void LCD_DisplayCounter (u16 counter)
{
	u8 str[8];
	u8 i = 0;
	u16 temp ;
	if (counter==0)
		temp = counter+1;
	else 
		temp = counter;
	while(temp)
	{
		temp/=10;
		i++;
	}
	str[i]='\0';
	for(u8 j = 0; j<i; j++)
	{
		str[i-j-1]=(counter%10)+'0';
		counter/=10;
	}
	LCD_SendString(str);
}

void LCD_SetCGRAMAddress()
{
	u8 address ;
	address=0x00;
	SetBit(address,PIN6_ID);
	Command(address);
	_delay_us(40);
}


void LCD_PrintCustomCharacter(u8 row, u8 column, u8 num)
{
	u8 CustomCharacter[] = {0x00,0x00,0x0A,0x1F,0x1F,0x0E,0x04,0x00};
	LCD_SetCGRAMAddress();
	for(int i = 0 ; i<8; i++)
	LCD_Data(CustomCharacter[i]);
	LCD_SetCursor(0,0);
	LCD_Data(0x00);
}


